(function ($) {
	 // Theme the resume control.
  Drupal.theme.viewsSlideshowControlsPause = function () {
    return "<span title=\"Resume Slideshow\" class=\"paused\"><span>" + Drupal.t('Resume Me') + "</span></span>";
  };
  // Theme the pause control.
  Drupal.theme.viewsSlideshowControlsPlay = function () {
    return "<span title=\"Pause Slideshow\" class=\"playing\"><span>" + Drupal.t('Pause Me') + "</span></span>";
  };

	Drupal.munrosSlideshow = Drupal.munrosSlideshow || {};
	Drupal.munrosSlideshow.transitionBegin = function (options) {
		slideNumber = options.slideNum + 1;
		$div = $('#bagger-map');
		$('[id^="home-page-"]').each( function() {
			$(this).hide();
		});
		$pin = $('#home-page-' + slideNumber).show();
	}
	Drupal.behaviors.munros_slideshow =  {
		attach: function(context, settings) {
			$div = $('#bagger-map');
			$('[id^="home-page-"]').each( function() {
					$(this).hover(function() {
						Drupal.viewsSlideshow.action({ "action": 'pause', "slideshowID": "front_page-block" });
					}, function() {
						Drupal.viewsSlideshow.action({ "action": 'play', "slideshowID": "front_page-block" });

					});
			});
			var height = $div.height();
			$('#bagger-map [id^="home-page-"]').each( function() {
				var lat, lng;
				$point = $(this);
				$(this).children().each(function(){
					var $span = $(this);
					if($span.hasClass('latitude')) {
						lat = $span.html();
						bottom = Math.lat2pix(lat, 58.6141, 55.8815, height) + 'px';
					}
					if($span.hasClass('longitude')) {
						lng = $span.html();
						left =  Math.lng2pix(lng,  -6.9265 , -1.6725, height) + 'px';
					}
				});
				$point.css('bottom', bottom);
				$point.css('left', left);
				//console.log(lat, lng);
			});
		}
	}	
	Math.lat2pix = function(latitude, topLatitude, bottomLatitude, height) {
		diff1 = Math.lat2mercator(latitude) - Math.lat2mercator(bottomLatitude);
		diff2 = Math.lat2mercator(topLatitude) - Math.lat2mercator(bottomLatitude);
		return diff1 / diff2 * height;	
  }
  Math.lng2pix = function(longitude, leftLongitude, rightLongitude, width) {
		pixel = width / (leftLongitude - rightLongitude) ;
    return ((leftLongitude - (longitude))*pixel);
  }
  Math.lat2mercator = function(lat) {
    if (lat > 89.5) lat = 89.5;
    if (lat < -89.5) lat = -89.5;
    r_major = 6378137.000;
    r_minor = 6356752.3142;
    temp = r_minor / r_major;
    es = 1.0 - (temp * temp);
    eccent = Math.sqrt(es);
    phi = (lat / 180) * Math.PI;
    sinphi = Math.sin(phi);
    con = eccent * sinphi;
    com = 0.5 * eccent;
    con = Math.pow((1.0-con)/(1.0+con), com);
    ts = Math.tan(0.5 * ((Math.PI*0.5) - phi))/con;
    y = - r_major * Math.log(ts);
    return y;
  }
})(jQuery);
