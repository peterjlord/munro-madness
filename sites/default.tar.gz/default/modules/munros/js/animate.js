function setAnimateMarkers(map) {
  var AnimateMarkersControlDiv = document.createElement('div');
  var AnimateMarkersControl = new AnimateMarkersScreenControl(AnimateMarkersControlDiv, map);

  AnimateMarkersControlDiv.index = 1;
  map.controls[google.maps.ControlPosition.TOP_RIGHT].push(AnimateMarkersControlDiv);
}
function AnimateMarkersScreenControl(controlDiv, map) {
		var d = document;
		var constants = map.constants.animate;
  	var controlUI = control_ui_init(d, constants);
    controlDiv.appendChild(controlUI);
		var controlText = control_ui_text(d, constants);
    controlUI.appendChild(controlText);
			
		google.maps.event.addDomListener(controlUI, 'click', function() {
			var container = $(this).parent().parent().parent().parent();
			container.toggleClass("animate");
				hasclass  =   container.hasClass("animate");
				if(hasclass) {
					control_ui_toggle_text(controlText, controlUI, constants, true);
					var counter = 0;
					var delay = function() { animateMarkers(counter, map.markerArray, map); };
					setTimeout(delay, 0);
				}
				else	{
					control_ui_toggle_text(controlText, controlUI, constants );
					stopAnimateMarkers(counter, map.markerArray, map);
				}
		});
}
function  stopAnimateMarkers(counter, markers, map) {
	for (var j in markers) {
		marker = markers[j];
	}
	map.setZoom(13);
	clearTimeout(map.t);
}
function animateMarkers(counter, markers, map) {
	var delay = function() { animateMarkers(counter, markers, map); };
	google.maps.event.trigger(markers[counter],'click');
	map.setZoom(14);
  map.panTo(markers[counter].position);

	counter = counter+1;
	map.t = setTimeout(delay, 5000);
}
