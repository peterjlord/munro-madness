function setFullScreen(map) {
	var homeControlDiv = document.createElement('div');
  var homeControl = new FullScreenControl(homeControlDiv, map);

  homeControlDiv.index = 1;
  map.controls[google.maps.ControlPosition.TOP_RIGHT].push(homeControlDiv);
}
function FullScreenControl(controlDiv, map) {
		var d = document;
  	var constants = map.constants.fullscreen;
  	var controlUI = control_ui_init(d, constants);
		controlDiv.appendChild(controlUI);
 		var controlText = control_ui_text(d, constants);

    controlUI.appendChild(controlText);

    google.maps.event.addDomListener(controlUI, 'click', function() {
		var container = jQuery(this).parent().parent().parent().parent();
    container.toggleClass("fullscreen");
    latlng = map.getCenter();
    hasclass  =   container.hasClass("fullscreen");
    if(hasclass) {
    	map.setCenter(latlng);
			control_ui_toggle_text(controlText, controlUI, constants, true);
    }	else	{
			control_ui_toggle_text(controlText, controlUI, constants);
		}
    google.maps.event.trigger(map, 'resize');
    map.setCenter(latlng);
	});
}

