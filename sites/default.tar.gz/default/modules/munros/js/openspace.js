function setOpenSpace(map) {
	var OpenSpaceControlDiv = document.createElement('div');
  var OpenSpaceControl = new OpenSpaceScreenControl(OpenSpaceControlDiv, map);

  OpenSpaceControlDiv.index = 1;
  map.controls[google.maps.ControlPosition.TOP_RIGHT].push(OpenSpaceControlDiv);
}
function OpenSpaceScreenControl(controlDiv, map) {
	var d = document;
	var constants = map.constants.openspace;
  var controlUI = control_ui_init(d, map.constants);
  controlDiv.appendChild(controlUI);
	var controlText = control_ui_text(d, constants);
  controlUI.appendChild(controlText);
	google.maps.event.addDomListener(controlUI, 'click', function() {
		var container = $(this).parent().parent().parent().parent();
		container.toggleClass("openspace");
		hasclass  =   container.hasClass("openspace");
		if(hasclass) {
			control_ui_toggle_text(controlText, controlUI, constants, true);
			openspace_setOpenspaceOn(d, map);
		}
		else	{
			control_ui_toggle_text(controlText, controlUI, constants);
			openspace_setOpenspaceOff(d, map);
		}
	});
}
function openspace_setCopyright(d, map) {
	var img = d.createElement('img');
  img.src = Drupal.settings.ukgridpoint.openspace.copyright_image;
  map.controls[google.maps.ControlPosition.LEFT_BOTTOM].push(img);

  var cpy = Drupal.settings.ukgridpoint.openspace.copyright;
  var dcpy = d.createElement('div');
  dcpy.innerHTML = cpy;
  map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(dcpy);
}
function openspace_setOpenspaceOn(d, map) {

	var warpedOsOpenSpaceMapType;
  var gridProjection = new GridProjection();
  gridProjection.initialize();
  warpedOsOpenSpaceMapType = new WarpedOsOpenSpaceMapType(Drupal.settings.ukgridpoint.openspace_key, Drupal.settings.ukgridpoint.openspace_domain, map);
  warpedOsOpenSpaceMapType.setOpacity(1);
  map.overlayMapTypes.insertAt(0, warpedOsOpenSpaceMapType);

  openspace_setCopyright(d, map);

  map.setOptions({mapTypeControl:false,});
}
function openspace_setOpenspaceOff(d, map) {
	var warpedOsOpenSpaceMapType; 
  var gridProjection = new GridProjection();
  gridProjection.initialize();
	warpedOsOpenSpaceMapType = new WarpedOsOpenSpaceMapType(Drupal.settings.ukgridpoint.openspace_key,  Drupal.settings.ukgridpoint.openspace_domain ,map);
  map.overlayMapTypes.removeAt(0, warpedOsOpenSpaceMapType);
  map.controls[google.maps.ControlPosition.LEFT_BOTTOM].pop();
  map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].pop();
	map.setOptions({mapTypeControl:true,});
}

