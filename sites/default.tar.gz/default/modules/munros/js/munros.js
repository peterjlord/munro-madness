(function($){
/******************* This function dynamically resizes this imagemap */
$.resize_imagemap = function() {
	$map = $('#large-map-selector');
  $('<img />').attr('src', $($map).attr('src')).load(function() {
  	v = parseFloat($.fn.jquery);
    w = this.width;
    h = this.height;
    var wPercent = $map.width()/100, hPercent = $map.height()/100, map = $map.attr('usemap').replace('#', ''), c = 'coords';
    console.log(map);
    $('map[name="' + map + '"]').find('area').each(function() {
    	if (!$(this).data(c))
      	$(this).data(c, $(this).attr(c));

      var coords = $(this).data(c).split(','), coordsPercent = new Array(coords.length);
      for (var i = 0; i < coordsPercent.length; ++i) {
      	if (i % 2 === 0)
        	coordsPercent[i] = parseInt(((coords[i]/w)*100)*wPercent);
        else
        	coordsPercent[i] = parseInt(((coords[i]/h)*100)*hPercent);
      }
      $(this).attr(c, coordsPercent.toString());
    });
  });
}
Drupal.behaviors.munros = {
  attach: function (context, settings) {
		width =  $(window).width();
		height =  $(window).height();
		$('#header-outer').prepend("Width = " + width + "px, Height = " + height + "px");
		$(".map-outer .map").each( function(index, domEle) {
			id = $(domEle).attr('id').replace('map-',''); 
			$.get("/ajax-map/" + id, function(data){
				var data = $.parseJSON(data);
				$(domEle).gmap({markers:data, fullscreen:true, setzoom:13, openspace:true, default:'openspace'});	
			});
		});
		if(Drupal.settings.arg[0]=='areas') {
			$.resize_imagemap();
			$(window).resize(function() {
				$.resize_imagemap();
    	});
			$('.main-map-image area').hover(
  			function () {
					$('#large-map-selector').attr("src","/sites/default/themes/mm/images/large-map-" + this.id + ".png");	
  			}, 
  			function () {
					$('#large-map-selctor').attr("src","/sites/default/themes/mm/images/large-map-blank.png");	
  			}
			);
		}
  }
}
})(jQuery);
