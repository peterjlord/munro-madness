function setEarth(map) {
	var homeControlDiv = document.createElement('div');
  var homeControl = new EarthControl(homeControlDiv, map);

  homeControlDiv.index = 1;
  map.controls[google.maps.ControlPosition.TOP_RIGHT].push(homeControlDiv);
}
function EarthControl(controlDiv, map) {
    controlDiv.style.padding = '5px';
    var controlUI = document.createElement('DIV');
    controlUI.style.backgroundColor = 'white';
    controlUI.style.borderStyle = 'solid';
    controlUI.style.borderWidth = '2px';
    controlUI.style.cursor = 'pointer';
    controlUI.style.textAlign = 'center';
    controlUI.title = 'Click to view the Map in Fullscreen Mode';
    controlDiv.appendChild(controlUI);

    var controlText = document.createElement('DIV');
    controlText.style.fontFamily = 'Arial,sans-serif';
    controlText.style.fontSize = '12px';
    controlText.style.paddingLeft = '4px';
    controlText.style.paddingRight = '4px';
    controlText.innerHTML = '<b>Fullscreen</b>';
    controlUI.appendChild(controlText);

    google.maps.event.addDomListener(controlUI, 'click', function() {
			var container = $(this).parent().parent().parent().parent();
      container.toggleClass("fullscreen");
      latlng = map.getCenter();
      hasclass  =   container.hasClass("fullscreen");
      if(hasclass) {
        // May do other stuff here
      	map.setCenter(latlng);
        controlText.innerHTML = '<b>Normal</b>';
        controlUI.title = 'Click to view the Map in Normal Mode';
      }	else	{
    		controlText.innerHTML = '<b>Fullscreen</b>';
    		controlUI.title = 'Click to view the Map in Fullscreen Mode';

			}
      google.maps.event.trigger(map, 'resize');
      map.setCenter(latlng);
    });
}

