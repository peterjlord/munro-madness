function setRuler(map) {
	var homeControlDiv = document.createElement('div');
  var homeControl = new RulerControl(homeControlDiv, map);

  homeControlDiv.index = 1;
  map.controls[google.maps.ControlPosition.TOP_RIGHT].push(homeControlDiv);
}
function RulerControl(controlDiv, map) {
    controlDiv.style.padding = '5px';
    var controlUI = document.createElement('DIV');
    controlUI.style.backgroundColor = 'white';
    controlUI.style.borderStyle = 'solid';
    controlUI.style.borderWidth = '2px';
    controlUI.style.cursor = 'pointer';
    controlUI.style.textAlign = 'center';
    controlUI.title = 'Click to view the Map in Fullscreen Mode';
    controlDiv.appendChild(controlUI);

    var controlText = document.createElement('DIV');
    controlText.style.fontFamily = 'Arial,sans-serif';
    controlText.style.fontSize = '12px';
    controlText.style.paddingLeft = '4px';
    controlText.style.paddingRight = '4px';
    controlText.innerHTML = '<b>Ruler</b>';
    controlUI.appendChild(controlText);

    google.maps.event.addDomListener(controlUI, 'click', function() {
			var container = $(this).parent().parent().parent().parent();
      container.toggleClass("ruler");
      latlng = map.getCenter();
      hasclass  =   container.hasClass("ruler");
      if(hasclass) {
        // May do other stuff here
      	map.setCenter(latlng);
        controlText.innerHTML = '<b>Remove</b>';
        controlUI.title = 'Click to view the Map in Normal Mode';

				var ruler1 = new google.maps.Marker({
					position: map.getCenter() ,
					map: map,
					draggable: true
				});
				var ruler2 = new google.maps.Marker({
					position: map.getCenter() ,
					map: map,
					draggable: true
				});
				var ruler1label = new Label({ map: map });
				var ruler2label = new Label({ map: map });
				ruler1label.bindTo('position', ruler1, 'position');
				ruler2label.bindTo('position', ruler2, 'position');

				var rulerpoly = new google.maps.Polyline({
					path: [ruler1.position, ruler2.position] ,
					strokeColor: "#FFFF00",
					strokeOpacity: .7,
					strokeWeight: 7
			});
			rulerpoly.setMap(map);
			ruler1label.set('text',distance( ruler1.getPosition().lat(), ruler1.getPosition().lng(), ruler2.getPosition().lat(), ruler2.getPosition().lng()));
			ruler2label.set('text',distance( ruler1.getPosition().lat(), ruler1.getPosition().lng(), ruler2.getPosition().lat(), ruler2.getPosition().lng()));

			google.maps.event.addListener(ruler1, 'drag', function() {
				rulerpoly.setPath([ruler1.getPosition(), ruler2.getPosition()]);
				r1lat = Math.round(ruler1.getPosition().lat()*1000)/1000;
				r1lng = Math.round(ruler1.getPosition().lng()*1000)/1000;
				r2lat = Math.round(ruler2.getPosition().lat()*1000)/1000;
				r2lng = Math.round(ruler2.getPosition().lng()*1000)/1000;
				ruler1label.set('text',distance( r1lat, r1lng, r2lat, r2lng) + ' ' + r1lat + ',' + r1lng);
				ruler2label.set('text',distance( r1lat, r1lng, r2lat, r2lng) + ' ' + r2lat + ',' + r2lng);
			});
			google.maps.event.addListener(ruler2, 'drag', function() {
				rulerpoly.setPath([ruler1.getPosition(), ruler2.getPosition()]);
				r1lat = Math.round(ruler1.getPosition().lat()*1000)/1000;
				r1lng = Math.round(ruler1.getPosition().lng()*1000)/1000;
				r2lat = Math.round(ruler2.getPosition().lat()*1000)/1000;
				r2lng = Math.round(ruler2.getPosition().lng()*1000)/1000;
				ruler1label.set('text',distance( r1lat, r1lng, r2lat, r2lng) + ' ' + r1lat + ',' + r1lng);
				ruler2label.set('text',distance( r1lat, r1lng, r2lat, r2lng) + ' ' + r2lat + ',' + r2lng);
			});


      }	else	{
    		controlText.innerHTML = '<b>Ruler</b>';
    		controlUI.title = 'Click to view the Map in Fullscreen Mode';
				alert("Remove Rulers");

			}
      google.maps.event.trigger(map, 'resize');
      map.setCenter(latlng);
    });
}
function distance(lat1,lon1,lat2,lon2) {
	var R = 6371; // km (change this constant to get miles)
	var dLat = (lat2-lat1) * Math.PI / 180;
	var dLon = (lon2-lon1) * Math.PI / 180; 
	var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
		Math.cos(lat1 * Math.PI / 180 ) * Math.cos(lat2 * Math.PI / 180 ) * 
		Math.sin(dLon/2) * Math.sin(dLon/2); 
	var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
	var d = R * c;
	if (d>1) return Math.round(d)+"km";
	else if (d<=1) return Math.round(d*1000)+"m";
	return d;
}

