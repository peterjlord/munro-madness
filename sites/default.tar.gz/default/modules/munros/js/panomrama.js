function setPanomrama(map) {
	var homeControlDiv = document.createElement('div');
  var homeControl = new PanomramaControl(homeControlDiv, map);

  homeControlDiv.index = 1;
  map.controls[google.maps.ControlPosition.TOP_RIGHT].push(homeControlDiv);
}
function PanomramaControl(controlDiv, map) {
    controlDiv.style.padding = '5px';
    var controlUI = document.createElement('DIV');
    controlUI.style.backgroundColor = 'white';
    controlUI.style.borderStyle = 'solid';
    controlUI.style.borderWidth = '2px';
    controlUI.style.cursor = 'pointer';
    controlUI.style.textAlign = 'center';
    controlUI.title = 'Click to view the Map in Fullscreen Mode';
    controlDiv.appendChild(controlUI);

    var controlText = document.createElement('DIV');
    controlText.style.fontFamily = 'Arial,sans-serif';
    controlText.style.fontSize = '12px';
    controlText.style.paddingLeft = '4px';
    controlText.style.paddingRight = '4px';
    controlText.innerHTML = '<b>Panomrama</b>';
    controlUI.appendChild(controlText);

    google.maps.event.addDomListener(controlUI, 'click', function() {
			var container = $(this).parent().parent().parent().parent();
      container.toggleClass("panomrama");
      latlng = map.getCenter();
      hasclass  =   container.hasClass("panomrama");
			var panoramioLayer = new google.maps.panoramio.PanoramioLayer();
			panoramioLayer.setMap(panoramioLayer.getMap() ? null : map);
      if(hasclass) {
        // May do other stuff here

				panoramioLayer.setMap(map);
      	map.setCenter(latlng);
        controlText.innerHTML = '<b>Images</b>';
        controlUI.title = 'Click to view the Map in Normal Mode';
      }	else	{
				//m	= panoramioLayer.getMap();
				//panoramioLayer.setMap({map:null});
				//debugger;
    		controlText.innerHTML = '<b>Fullscreen</b>';
    		controlUI.title = 'Click to view the Map in Fullscreen Mode';

			}
      google.maps.event.trigger(map, 'resize');
      map.setCenter(latlng);
    });
}

