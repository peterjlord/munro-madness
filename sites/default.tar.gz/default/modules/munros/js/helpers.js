// Define a new function.
	var control_ui_init = function(d, constants) {
		var controlUI = d.createElement('div');
		jQuery(controlUI).addClass('map-button');
		controlUI.title = constants.title_title;
		return controlUI;
	}
	var control_ui_text = function(d, constants) {
		var controlText = d.createElement('div');
  	jQuery(controlText).addClass('map-button-text');
  	controlText.innerHTML = constants.title;
		return controlText;
	}
	var control_ui_toggle_text = function(controlText, controlUI, constants, hasClass) {
		if(hasClass) {
			controlText.innerHTML = constants.title_back;
  		controlUI.title = constants.title_back_title;
		} else {
			controlText.innerHTML = constants.title;
  		controlUI.title = constants.title_title;
	}
}
