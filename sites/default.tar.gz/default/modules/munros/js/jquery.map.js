(function( $ ) {
	// global google maps objects
  var $googlemaps = google.maps, opts, methods = {};
	var markerArray = [];
	var methods = {
    init : function( options ) { 
      // THIS 
			opts = $.extend({}, $.fn.gmap.defaults, options);
			return this.each(function () {
				var $this = $(this); 
				center = methods._getMapCenter(opts);
				var  mapOptions = {
                        zoom: opts.zoom,
                        center: center,
                        mapTypeControl: opts.mapTypeControl,
                        mapTypeControlOptions: {},
                        zoomControl: opts.zoomControl,
                        zoomControlOptions: {},
                        panControl : opts.panControl,
                        panControlOptions: {},
                        scaleControl : opts.scaleControl,
                        scaleControlOptions: {},
                        streetViewControl: opts.streetViewControl,
                        streetViewControlOptions: {},
                        mapTypeId: opts.maptype,
                        scrollwheel: opts.scrollwheel,
                        maxZoom: opts.maxZoom,
                        minZoom: opts.minZoom
                    };
				var $gmap = new $googlemaps.Map(this, mapOptions);
				$gmap.infoWindow = new $googlemaps.InfoWindow({content: "holding...",maxWidth: 500 });
				$gmap.constants = [];

				// Create map and set initial options
        $this.data("$gmap", $gmap);
				$this.data('gmap', {
           'opts': opts,
           'gmap': $gmap,
           'markers': [],
           'markerKeys' : {},
           'infoWindow': null,
           'clusters': []
        });
				methods.features($gmap, $this);
				
			});
    },
    _getMapCenter : function(opts ) {
			markers = opts.markers;
			center = new $googlemaps.LatLng(markers[0].latitude, markers[0].longitude);
			return center;	
    },
    features : function($gmap, $this) { 
			methods.markers($gmap, $this);
			methods.fullscreen($gmap, $this);
    },
		markers : function($gmap, $this) {
			data	=	$this.data('gmap');
			markers	=	data.opts.markers;
			for (var j in data.opts.markers) {
				gmarker = methods.createMarker($gmap, opts.markers[j]);
				methods.createInfoWindow($gmap, opts.markers[j], gmarker);
			}	
		},
		createMarker: function($gmap, marker) {
			console.log(marker);
			var gpoint = new $googlemaps.LatLng(marker.latitude, marker.longitude);
			
			var gmarker = new $googlemaps.Marker({
      	position: gpoint,
      	title: marker.title,
      	map: $gmap,
    	});
    	markerArray.push(gmarker);
    	return gmarker;
		},
		createInfoWindow : function($gmap, marker, gmarker) {
			if(marker.html) {
      	$googlemaps.event.addListener(gmarker, 'click', function() {
        	$gmap.infoWindow.setContent(marker.html);
        	$gmap.infoWindow.open($gmap, this);
      	});
   		}
		},
    fullscreen : function($gmap, $this) { 
			$gmap.constants.fullscreen = Drupal.settings.munros.fullscreen;
      var homeControlDiv = document.createElement('div');
      var homeControl = new FullScreenControl(homeControlDiv, $gmap);
      homeControlDiv.index = 1;
      $gmap.controls[$googlemaps.ControlPosition.TOP_RIGHT].push(homeControlDiv);

      // !!! 
    }
  };
	// Main Gmap 
	$.fn.gmap = function( method ) {
    
    // Method calling logic
    if ( methods[method] ) {
      return methods[ method ].apply( this, Array.prototype.slice.call( arguments, 1 ));
    } else if ( typeof method === 'object' || ! method ) {
      return methods.init.apply( this, arguments );
    } else {
      $.error( 'Method ' +  method + ' does not exist on jQuery.tooltip' );
    }    
  
  };
	$.fn.gmap.defaults = {
		log:                     false,
    address:                 '',
    latitude:                null,
    longitude:               null,
    zoom:                    13,
    maxZoom: 				 null,
    minZoom: 				 null,
    markers:                 [],
    controls:                {},
    scrollwheel:             true,
    maptype:                 google.maps.MapTypeId.TERRAIN,

    mapTypeControl:          true,
    zoomControl:             true,
    panControl:              false,
    scaleControl:            false,
    streetViewControl:       true,

	};
})( jQuery );
