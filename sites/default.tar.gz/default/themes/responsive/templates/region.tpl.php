<?php if (!empty($content)): ?>
<div class="<?php print $classes; ?>">
  <?php print $content; ?>
</div>
<?php endif; ?> <!-- /.region -->
