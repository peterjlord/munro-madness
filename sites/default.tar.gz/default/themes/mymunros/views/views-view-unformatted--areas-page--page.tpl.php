<?php
	$path = path_to_theme();
	$images = $path . '/images';
	echo <<<EOD
<div class="main-map-image">
<img src="$images/large-map.png" />
</div>
EOD;

