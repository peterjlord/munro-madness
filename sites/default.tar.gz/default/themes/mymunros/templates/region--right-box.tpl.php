<?php if ($content): ?>
  <div class="inner">
    <?php print $content; ?>
  </div>
<?php endif; ?>
