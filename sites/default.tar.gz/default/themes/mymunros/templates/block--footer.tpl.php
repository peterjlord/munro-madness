<?php if ($content): ?>
  <div class="wrapper">
    <?php print $content; ?>
  </div>
<?php endif; ?>

