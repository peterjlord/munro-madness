<?php
	echo $content;
?>
