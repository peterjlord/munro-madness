<?php
/**
 * @file
 * Display Suite Munros Teaser template.
 *
 * Available variables:
 *
 * Layout:
 * - $classes: String of classes that can be used to style this layout.
 * - $contextual_links: Renderable array of contextual links.
 *
 * Regions:
 *
 * - $top: Rendered content for the "Top" region.
 * - $top_classes: String of classes that can be used to style the "Top" region.
 *
 * - $middle_left: Rendered content for the "Middle Left" region.
 * - $middle_left_classes: String of classes that can be used to style the "Middle Left" region.
 *
 * - $middle_right: Rendered content for the "Middle Right" region.
 * - $middle_right_classes: String of classes that can be used to style the "Middle Right" region.
 *
 * - $bottom_left: Rendered content for the "Bottom Left" region.
 * - $bottom_left_classes: String of classes that can be used to style the "Bottom Left" region.
 *
 * - $bottom_right: Rendered content for the "Bottom Right" region.
 * - $bottom_right_classes: String of classes that can be used to style the "Bottom Right" region.
 */
?>

<div class="<?php print $classes; ?> clearfix">
  <?php if (isset($title_suffix['contextual_links'])): ?>
    <?php print render($title_suffix['contextual_links']); ?>
  <?php endif; ?>

  <?php if ($top): ?>
    <div class="ds-top<?php print $top_classes; ?>">
      <?php print $top; ?>
    </div>
  <?php endif; ?>

  <?php if ($middle_left): ?>
    <div class="ds-middle-left<?php print $middle_left_classes; ?>">
      <?php print $middle_left; ?>
    </div>
  <?php endif; ?>

  <?php if ($middle_right): ?>
    <div class="ds-middle-right<?php print $middle_right_classes; ?>">
      <?php print $middle_right; ?>
    </div>
  <?php endif; ?>

  <?php if ($bottom_left): ?>
    <div class="ds-bottom-left<?php print $bottom_left_classes; ?>">
      <?php print $bottom_left; ?>
    </div>
  <?php endif; ?>

  <?php if ($bottom_right): ?>
    <div class="ds-bottom-right<?php print $bottom_right_classes; ?>">
      <?php print $bottom_right; ?>
    </div>
  <?php endif; ?>
</div>
