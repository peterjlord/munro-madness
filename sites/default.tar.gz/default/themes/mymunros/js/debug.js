(function ($) {
    $(document).ready(function(){
			var w = $(window).width();
			var h = $(document).height();
			$('#adsense').prepend('<div id="dimensions">' + w + "x" + h + '</div>');	
			$('#dimensions').css('position', 'absolute');
			$('#dimensions').css('margin', 'auto');
			$('#dimensions').css('top', '20%');
			$('#dimensions').css('left', '20%');
			$(window).bind('resize', function () { 
				var w = $(window).width();
				var h = $(document).height();
				var emh = $(h).toEm(); 
				var emw = $(w).toEm(); 
				$('#dimensions').html(w + "px x " + h + "px<br />" + emw + "x" + emh);	
			});
    });
		$.fn.toEm = function(settings){
	settings = jQuery.extend({
		scope: 'body'
	}, settings);
	var that = parseInt(this[0],10),
		scopeTest = jQuery('<div style="display: none; font-size: 1em; margin: 0; padding:0; height: auto; line-height: 1; border:0;">&nbsp;</div>').appendTo(settings.scope),
		scopeVal = scopeTest.height();
	scopeTest.remove();
	return (that / scopeVal).toFixed(2) + 'em';
};


$.fn.toPx = function(settings){
	settings = jQuery.extend({
		scope: 'body'
	}, settings);
	var that = parseFloat(this[0]),
		scopeTest = jQuery('<div style="display: none; font-size: 1em; margin: 0; padding:0; height: auto; line-height: 1; border:0;">&nbsp;</div>').appendTo(settings.scope),
		scopeVal = scopeTest.height();
	scopeTest.remove();
	return Math.round(that * scopeVal) + 'px';
};
})(jQuery); 
