<?php
	$links = array();
	$options = array();
	$options['html'] = TRUE;
	$options['attributes']['class'] = 'area';
	foreach($view->result as $area) {
		$url	=	url('node/' . $area->nid);	
		switch($area->nid) {
			case '904':
				$poly = '270,674,270,731,219,780,238,828,561,681,516,596,461,600,392,661,314,658';break;
			case '905':
				$poly = '322,627,369,582,431,587,482,574,499,599,465,603,411,656,345,675,324,629';break;
			case '906':
				$poly = '244,585,264,588,296,570,370,583,329,631,347,665,301,659,267,677,206,642,241,583';break;
			case '907':
				$poly = '239,519,266,523,291,513,341,515,420,467,376,567,369,592,292,573,268,588,242,587,238,520';break;
			case '908':
				$poly = '413,470,440,459,433,552,453,557,485,576,413,594,363,591,365,564,419,469';break;
			case '909':
				$poly = '437,458,454,449,464,497,549,494,564,621,514,635,463,560,423,555,438,456';break;
			case '910':
				$poly = '544,491,665,466,685,481,753,461,653,656,553,678,532,646,552,611,544,493';break;
			case '911':
				$poly = '585,294,453,451,459,494,757,469,796,292,590,294';break;
			case '912':
				$poly = '407,350,262,521,271,529,299,516,342,516,466,448,593,302,519,274,412,346';break;
			case '913':
				$poly = '151,525,271,527,355,420,257,446,188,412,133,527';break;
			case '914':
				$poly = '195,416,265,450,354,420,418,343,363,345,309,392,202,394,193,418';break;
			case '915':
				$poly = '167,401,211,383,229,342,322,304,446,297,384,351,303,395,205,399,192,419,167,408';break;
			case '916':
				$poly = '156,392,205,388,280,321,248,322,171,245,159,245,152,390';break;
			case '917':
				$poly = '180,271,250,323,322,310,339,313,335,297,214,195,161,252';break;
			case '918':
				$poly = '250,231,336,303,373,331,484,247,405,244,333,201,254,211,247,230';break;
			case '919':
				$poly = '209,179,251,215,367,219,398,249,446,244,633,13,285,9,210,180,212,179,215,180';break;
			case '920':
				$poly = '69,288,185,422,129,503,3,376,15,295';break;
			default:
				$poly = '124,430,115,405,144,380,144,359,226,338,237,315,265,315,294,356';
				break;
		}
		$a	=	"<area id=\"node-$area->nid\" shape=\"poly\" coords=\"$poly\" href=\"$url\" title=\"$area->node_title\" alt=\"$area->node_title\" />";
		$areas[] = $a;
	}
	// Add extra on for Mull
	$poly = '99,592,194,653,171,700,68,713,67,606';
	$area	=	"<area id=\"node-$area->nid\" shape=\"poly\" coords=\"$poly\" href=\"$url\" title=\"$area->node_title\" alt=\"$area->node_title\" />";
	$areas[] = $area;

	
	$areas = implode($areas);
	$path = path_to_theme();
	$images = $path . '/images';
	echo <<<EOD
<div class="main-map-image">
<img id="large-map" src="/$images/large-map.png" usemap="#munro-bagging-areas" />
<img id="large-map-selector" src="/$images/large-map-blank.png" usemap="#munro-bagging-areas" />
	<map name="munro-bagging-areas">
	$areas
	</map>
</div>
EOD;

