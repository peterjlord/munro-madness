<?php if ($content): ?>
  <nav class="main-nav-wrap">
    <?php print $content; ?>
  </nav>
<?php endif; ?>
